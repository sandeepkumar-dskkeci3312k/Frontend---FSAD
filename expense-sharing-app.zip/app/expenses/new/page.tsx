"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { CalendarIcon } from "lucide-react"
import { format } from "date-fns"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { cn } from "@/lib/utils"

export default function NewExpensePage() {
  const [date, setDate] = useState(new Date())
  const [amount, setAmount] = useState("")
  const [description, setDescription] = useState("")
  const [selectedGroup, setSelectedGroup] = useState("")
  const [paidBy, setPaidBy] = useState("you")
  const [splitMethod, setSplitMethod] = useState("equal")

  // Mock data - in a real app, this would come from your database
  const groups = [
    { id: "apartment", name: "Apartment" },
    { id: "trip-to-nyc", name: "Trip to NYC" },
    { id: "dinner-club", name: "Dinner Club" },
    { id: "office-lunch", name: "Office Lunch" },
  ]

  const groupMembers = {
    apartment: [
      { id: "you", name: "You" },
      { id: "alex", name: "Alex" },
      { id: "jamie", name: "Jamie" },
      { id: "taylor", name: "Taylor" },
    ],
    "trip-to-nyc": [
      { id: "you", name: "You" },
      { id: "alex", name: "Alex" },
      { id: "jamie", name: "Jamie" },
      { id: "taylor", name: "Taylor" },
      { id: "jordan", name: "Jordan" },
      { id: "casey", name: "Casey" },
    ],
    "dinner-club": [
      { id: "you", name: "You" },
      { id: "alex", name: "Alex" },
      { id: "jamie", name: "Jamie" },
      { id: "taylor", name: "Taylor" },
      { id: "morgan", name: "Morgan" },
    ],
    "office-lunch": [
      { id: "you", name: "You" },
      { id: "alex", name: "Alex" },
      { id: "jamie", name: "Jamie" },
      { id: "taylor", name: "Taylor" },
      { id: "jordan", name: "Jordan" },
      { id: "casey", name: "Casey" },
      { id: "morgan", name: "Morgan" },
      { id: "riley", name: "Riley" },
    ],
  }

  const currentMembers = selectedGroup ? groupMembers[selectedGroup] : []

  const handleSubmit = (e) => {
    e.preventDefault()
    // Here you would typically save the expense data
    console.log({
      date,
      amount: Number.parseFloat(amount),
      description,
      group: selectedGroup,
      paidBy,
      splitMethod,
    })
    // Then redirect to the group page
    if (selectedGroup) {
      window.location.href = `/groups/${selectedGroup}`
    } else {
      window.location.href = "/"
    }
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-2xl">
      <h1 className="text-3xl font-bold mb-6">Add an Expense</h1>

      <form onSubmit={handleSubmit}>
        <Card>
          <CardHeader>
            <CardTitle>Expense Details</CardTitle>
            <CardDescription>Add a new expense to track who paid and how it should be split</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="group">Group</Label>
              <Select value={selectedGroup} onValueChange={setSelectedGroup} required>
                <SelectTrigger id="group">
                  <SelectValue placeholder="Select a group" />
                </SelectTrigger>
                <SelectContent>
                  {groups.map((group) => (
                    <SelectItem key={group.id} value={group.id}>
                      {group.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Input
                id="description"
                placeholder="What was this expense for?"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="amount">Amount</Label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2">$</span>
                <Input
                  id="amount"
                  type="number"
                  step="0.01"
                  min="0.01"
                  className="pl-8"
                  placeholder="0.00"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="date">Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant={"outline"}
                    className={cn("w-full justify-start text-left font-normal", !date && "text-muted-foreground")}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {date ? format(date, "PPP") : <span>Pick a date</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar mode="single" selected={date} onSelect={setDate} initialFocus />
                </PopoverContent>
              </Popover>
            </div>

            <div className="space-y-2">
              <Label>Paid by</Label>
              <RadioGroup value={paidBy} onValueChange={setPaidBy} className="grid grid-cols-2 gap-4">
                {currentMembers.map((member) => (
                  <div key={member.id} className="flex items-center space-x-2">
                    <RadioGroupItem value={member.id} id={`paid-by-${member.id}`} />
                    <Label htmlFor={`paid-by-${member.id}`} className="flex items-center gap-2">
                      <Avatar className="h-6 w-6">
                        <AvatarImage src={`/placeholder.svg?height=24&width=24`} alt={member.name} />
                        <AvatarFallback>{member.name.charAt(0).toUpperCase()}</AvatarFallback>
                      </Avatar>
                      {member.name}
                    </Label>
                  </div>
                ))}
              </RadioGroup>
            </div>

            <div className="space-y-2">
              <Label>Split method</Label>
              <RadioGroup value={splitMethod} onValueChange={setSplitMethod} className="grid gap-2">
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="equal" id="split-equal" />
                  <Label htmlFor="split-equal">Split equally</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="exact" id="split-exact" />
                  <Label htmlFor="split-exact">Split by exact amounts</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="percent" id="split-percent" />
                  <Label htmlFor="split-percent">Split by percentages</Label>
                </div>
              </RadioGroup>
            </div>

            {splitMethod === "equal" && (
              <div className="p-3 bg-muted rounded-md">
                <p className="text-sm">
                  Each person pays: ${amount ? (Number.parseFloat(amount) / currentMembers.length).toFixed(2) : "0.00"}
                </p>
              </div>
            )}

            {splitMethod === "exact" && (
              <div className="space-y-3">
                {currentMembers.map((member) => (
                  <div key={member.id} className="flex items-center gap-2">
                    <Avatar className="h-6 w-6">
                      <AvatarImage src={`/placeholder.svg?height=24&width=24`} alt={member.name} />
                      <AvatarFallback>{member.name.charAt(0).toUpperCase()}</AvatarFallback>
                    </Avatar>
                    <span className="text-sm">{member.name}</span>
                    <div className="relative ml-auto">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2">$</span>
                      <Input className="w-24 pl-8" placeholder="0.00" type="number" step="0.01" min="0" />
                    </div>
                  </div>
                ))}
              </div>
            )}

            {splitMethod === "percent" && (
              <div className="space-y-3">
                {currentMembers.map((member) => (
                  <div key={member.id} className="flex items-center gap-2">
                    <Avatar className="h-6 w-6">
                      <AvatarImage src={`/placeholder.svg?height=24&width=24`} alt={member.name} />
                      <AvatarFallback>{member.name.charAt(0).toUpperCase()}</AvatarFallback>
                    </Avatar>
                    <span className="text-sm">{member.name}</span>
                    <div className="relative ml-auto">
                      <Input className="w-24 pr-8" placeholder="0" type="number" step="1" min="0" max="100" />
                      <span className="absolute right-3 top-1/2 -translate-y-1/2">%</span>
                    </div>
                  </div>
                ))}
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="notes">Notes (Optional)</Label>
              <Textarea id="notes" placeholder="Add any additional details..." />
            </div>
          </CardContent>
          <CardFooter>
            <Button type="submit" className="w-full bg-green-600 hover:bg-green-700">
              Save Expense
            </Button>
          </CardFooter>
        </Card>
      </form>
    </div>
  )
}
