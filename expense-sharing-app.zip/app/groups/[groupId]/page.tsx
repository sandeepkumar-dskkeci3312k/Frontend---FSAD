import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { PlusCircle, DollarSign, ArrowLeftRight } from "lucide-react"

export default function GroupDetailPage({ params }) {
  // In a real app, you would fetch the group data based on the groupId
  const groupId = params.groupId
  const groupName = groupId
    .split("-")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ")

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold">{groupName}</h1>
        <div className="flex gap-2">
          <Link href="/expenses/new">
            <Button className="bg-green-600 hover:bg-green-700">
              <PlusCircle className="h-4 w-4 mr-2" />
              Add Expense
            </Button>
          </Link>
          <Link href="/settlements/new">
            <Button variant="outline">
              <ArrowLeftRight className="h-4 w-4 mr-2" />
              Settle Up
            </Button>
          </Link>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center">
              <DollarSign className="h-5 w-5 mr-2 text-green-500" />
              Total Balance
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold text-green-600">$125.50</p>
            <p className="text-sm text-muted-foreground">You are owed $125.50 in this group</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle>Group Members</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex -space-x-2">
              <Avatar className="border-2 border-background">
                <AvatarImage src="/placeholder.svg?height=40&width=40" alt="@you" />
                <AvatarFallback>YOU</AvatarFallback>
              </Avatar>
              <Avatar className="border-2 border-background">
                <AvatarImage src="/placeholder.svg?height=40&width=40" alt="@alex" />
                <AvatarFallback>AL</AvatarFallback>
              </Avatar>
              <Avatar className="border-2 border-background">
                <AvatarImage src="/placeholder.svg?height=40&width=40" alt="@jamie" />
                <AvatarFallback>JA</AvatarFallback>
              </Avatar>
              <Avatar className="border-2 border-background">
                <AvatarImage src="/placeholder.svg?height=40&width=40" alt="@taylor" />
                <AvatarFallback>TA</AvatarFallback>
              </Avatar>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle>Recent Activity</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <p className="text-sm">Alex paid $45.50 for Dinner</p>
            <p className="text-sm">You paid $87.25 for Groceries</p>
            <p className="text-sm">Jamie settled $35.75 with you</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="expenses" className="w-full">
        <TabsList className="grid w-full grid-cols-3 mb-6">
          <TabsTrigger value="expenses">Expenses</TabsTrigger>
          <TabsTrigger value="balances">Balances</TabsTrigger>
          <TabsTrigger value="activity">Activity</TabsTrigger>
        </TabsList>

        <TabsContent value="expenses" className="space-y-4">
          <ExpenseCard
            description="Groceries"
            amount={87.25}
            paidBy="You"
            date="2 days ago"
            splits={[
              { name: "You", amount: 21.81, isPayer: true },
              { name: "Alex", amount: 21.81, isPayer: false },
              { name: "Jamie", amount: 21.81, isPayer: false },
              { name: "Taylor", amount: 21.82, isPayer: false },
            ]}
          />
          <ExpenseCard
            description="Dinner at Italian Restaurant"
            amount={135.5}
            paidBy="Alex"
            date="Yesterday"
            splits={[
              { name: "You", amount: 33.88, isPayer: false },
              { name: "Alex", amount: 33.87, isPayer: true },
              { name: "Jamie", amount: 33.87, isPayer: false },
              { name: "Taylor", amount: 33.88, isPayer: false },
            ]}
          />
          <ExpenseCard
            description="Utilities"
            amount={120.0}
            paidBy="You"
            date="Last week"
            splits={[
              { name: "You", amount: 30.0, isPayer: true },
              { name: "Alex", amount: 30.0, isPayer: false },
              { name: "Jamie", amount: 30.0, isPayer: false },
              { name: "Taylor", amount: 30.0, isPayer: false },
            ]}
          />
          <ExpenseCard
            description="Movie tickets"
            amount={48.0}
            paidBy="Jamie"
            date="2 weeks ago"
            splits={[
              { name: "You", amount: 12.0, isPayer: false },
              { name: "Alex", amount: 12.0, isPayer: false },
              { name: "Jamie", amount: 12.0, isPayer: true },
              { name: "Taylor", amount: 12.0, isPayer: false },
            ]}
          />
        </TabsContent>

        <TabsContent value="balances">
          <Card>
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold mb-4">Group Balances</h3>

              <div className="space-y-4">
                <div className="flex justify-between items-center py-2 border-b">
                  <div className="flex items-center gap-2">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src="/placeholder.svg?height=32&width=32" alt="Alex" />
                      <AvatarFallback>AL</AvatarFallback>
                    </Avatar>
                    <span>Alex</span>
                  </div>
                  <span className="text-red-500 font-medium">owes you $51.81</span>
                </div>

                <div className="flex justify-between items-center py-2 border-b">
                  <div className="flex items-center gap-2">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src="/placeholder.svg?height=32&width=32" alt="Jamie" />
                      <AvatarFallback>JA</AvatarFallback>
                    </Avatar>
                    <span>Jamie</span>
                  </div>
                  <span className="text-red-500 font-medium">owes you $39.81</span>
                </div>

                <div className="flex justify-between items-center py-2 border-b">
                  <div className="flex items-center gap-2">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src="/placeholder.svg?height=32&width=32" alt="Taylor" />
                      <AvatarFallback>TA</AvatarFallback>
                    </Avatar>
                    <span>Taylor</span>
                  </div>
                  <span className="text-red-500 font-medium">owes you $33.88</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="activity">
          <Card>
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold mb-4">Recent Activity</h3>

              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="bg-green-100 p-2 rounded-full">
                    <DollarSign className="h-5 w-5 text-green-600" />
                  </div>
                  <div>
                    <p className="font-medium">You added "Groceries" ($87.25)</p>
                    <p className="text-sm text-muted-foreground">2 days ago</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="bg-green-100 p-2 rounded-full">
                    <DollarSign className="h-5 w-5 text-green-600" />
                  </div>
                  <div>
                    <p className="font-medium">Alex added "Dinner at Italian Restaurant" ($135.50)</p>
                    <p className="text-sm text-muted-foreground">Yesterday</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="bg-green-100 p-2 rounded-full">
                    <ArrowLeftRight className="h-5 w-5 text-green-600" />
                  </div>
                  <div>
                    <p className="font-medium">Jamie settled $35.75 with you</p>
                    <p className="text-sm text-muted-foreground">3 days ago</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="bg-green-100 p-2 rounded-full">
                    <DollarSign className="h-5 w-5 text-green-600" />
                  </div>
                  <div>
                    <p className="font-medium">You added "Utilities" ($120.00)</p>
                    <p className="text-sm text-muted-foreground">Last week</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

function ExpenseCard({ description, amount, paidBy, date, splits }) {
  const isPaidByYou = paidBy === "You"

  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex justify-between items-center mb-4">
          <div>
            <h3 className="font-medium">{description}</h3>
            <p className="text-xs text-muted-foreground">{date}</p>
          </div>
          <div className="text-right">
            <p className="font-bold">${amount.toFixed(2)}</p>
            <p className={`text-xs ${isPaidByYou ? "text-green-600" : "text-muted-foreground"}`}>Paid by {paidBy}</p>
          </div>
        </div>

        <div className="space-y-2 text-sm">
          <p className="text-xs text-muted-foreground">Split equally</p>
          {splits.map((split, index) => (
            <div key={index} className="flex justify-between items-center">
              <span>{split.name}</span>
              <span className={split.isPayer ? "text-green-600" : ""}>
                {split.isPayer ? "paid" : "owes"} ${split.amount.toFixed(2)}
              </span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
