"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { X } from "lucide-react"

export default function NewGroupPage() {
  const [groupName, setGroupName] = useState("")
  const [description, setDescription] = useState("")
  const [newMember, setNewMember] = useState("")
  const [members, setMembers] = useState([{ id: 1, name: "You", email: "you@example.com" }])

  const addMember = () => {
    if (newMember.trim() === "") return

    // Simple email validation
    const isEmail = /\S+@\S+\.\S+/.test(newMember)
    const memberName = isEmail ? newMember.split("@")[0] : newMember

    setMembers([
      ...members,
      {
        id: members.length + 1,
        name: memberName,
        email: isEmail ? newMember : `${newMember.toLowerCase().replace(/\s+/g, ".")}@example.com`,
      },
    ])
    setNewMember("")
  }

  const removeMember = (id) => {
    setMembers(members.filter((member) => member.id !== id))
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    // Here you would typically save the group data
    console.log({ groupName, description, members })
    // Then redirect to the new group page
    window.location.href = `/groups/${groupName.toLowerCase().replace(/\s+/g, "-")}`
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-2xl">
      <h1 className="text-3xl font-bold mb-6">Create a New Group</h1>

      <form onSubmit={handleSubmit}>
        <Card>
          <CardHeader>
            <CardTitle>Group Details</CardTitle>
            <CardDescription>Create a group to start tracking shared expenses</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Group Name</Label>
              <Input
                id="name"
                placeholder="e.g., Apartment, Trip to NYC, Office Lunch"
                value={groupName}
                onChange={(e) => setGroupName(e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description (Optional)</Label>
              <Textarea
                id="description"
                placeholder="What's this group for?"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
              />
            </div>

            <div className="space-y-4">
              <Label>Group Members</Label>

              <div className="space-y-2">
                {members.map((member) => (
                  <div key={member.id} className="flex items-center justify-between p-2 border rounded-md">
                    <div className="flex items-center gap-2">
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={`/placeholder.svg?height=32&width=32`} alt={member.name} />
                        <AvatarFallback>{member.name.charAt(0).toUpperCase()}</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="text-sm font-medium">{member.name}</p>
                        <p className="text-xs text-muted-foreground">{member.email}</p>
                      </div>
                    </div>
                    {member.id !== 1 && (
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        onClick={() => removeMember(member.id)}
                        aria-label={`Remove ${member.name}`}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                ))}
              </div>

              <div className="flex gap-2">
                <Input
                  placeholder="Add by name or email"
                  value={newMember}
                  onChange={(e) => setNewMember(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault()
                      addMember()
                    }
                  }}
                />
                <Button type="button" variant="outline" onClick={addMember}>
                  Add
                </Button>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button type="submit" className="w-full bg-green-600 hover:bg-green-700">
              Create Group
            </Button>
          </CardFooter>
        </Card>
      </form>
    </div>
  )
}
