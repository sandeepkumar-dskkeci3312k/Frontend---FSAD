import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { PlusCircle, Search, Users } from "lucide-react"

export default function GroupsPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold">Your Groups</h1>
        <Link href="/groups/new">
          <Button className="bg-green-600 hover:bg-green-700">
            <PlusCircle className="h-4 w-4 mr-2" />
            New Group
          </Button>
        </Link>
      </div>

      <div className="relative mb-6">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input placeholder="Search groups..." className="pl-10" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <GroupCard
          name="Apartment"
          members={4}
          balance={125.5}
          isPositive={true}
          lastActivity="Groceries • 2 days ago"
        />
        <GroupCard
          name="Trip to NYC"
          members={6}
          balance={75.25}
          isPositive={false}
          lastActivity="Taxi rides • May 5"
        />
        <GroupCard name="Dinner Club" members={5} balance={95.0} isPositive={true} lastActivity="Dinner • Yesterday" />
        <GroupCard name="Office Lunch" members={8} balance={25.0} isPositive={true} lastActivity="Coffee run • May 3" />
        <GroupCard name="Game Night" members={7} balance={0} isPositive={true} lastActivity="Snacks • April 28" />
        <GroupCard
          name="Vacation Fund"
          members={3}
          balance={150.0}
          isPositive={true}
          lastActivity="Hotel deposit • April 15"
        />
      </div>
    </div>
  )
}

function GroupCard({ name, members, balance, isPositive, lastActivity }) {
  return (
    <Link href={`/groups/${name.toLowerCase().replace(/\s+/g, "-")}`}>
      <Card className="h-full hover:shadow-md transition-shadow">
        <CardContent className="p-6">
          <div className="flex justify-between items-start mb-4">
            <h3 className="text-xl font-semibold">{name}</h3>
            <div className="flex items-center text-muted-foreground">
              <Users className="h-4 w-4 mr-1" />
              <span className="text-sm">{members}</span>
            </div>
          </div>

          <div className="mb-4">
            <p className={`text-lg font-bold ${isPositive ? "text-green-600" : "text-red-500"}`}>
              {isPositive ? "+" : "-"}${Math.abs(balance).toFixed(2)}
            </p>
            <p className="text-sm text-muted-foreground">
              {balance === 0 ? "all settled up" : isPositive ? "you are owed" : "you owe"}
            </p>
          </div>

          <div className="text-xs text-muted-foreground border-t pt-2">Last activity: {lastActivity}</div>
        </CardContent>
      </Card>
    </Link>
  )
}
