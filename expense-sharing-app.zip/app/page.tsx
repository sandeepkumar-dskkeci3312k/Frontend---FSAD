import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { DollarSign, PlusCircle, Users } from "lucide-react"

export default function Home() {
  return (
    <div className="container mx-auto px-4 py-8">
      <header className="mb-8 text-center">
        <h1 className="text-4xl font-bold text-green-600 mb-2">SplitWise</h1>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Simplify expense sharing with friends, roommates, and groups. Track who owes whom and settle up easily.
        </p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center">
              <DollarSign className="h-5 w-5 mr-2 text-green-500" />
              Total Balance
            </CardTitle>
            <CardDescription>Your overall balance across all groups</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold text-green-600">$245.50</p>
            <p className="text-sm text-muted-foreground">You are owed $320.75 and you owe $75.25</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center">
              <Users className="h-5 w-5 mr-2 text-green-500" />
              Active Groups
            </CardTitle>
            <CardDescription>Groups you're currently part of</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">4</p>
            <p className="text-sm text-muted-foreground">Apartment, Trip to NYC, Dinner Club, Office Lunch</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center">
              <DollarSign className="h-5 w-5 mr-2 text-green-500" />
              Recent Activity
            </CardTitle>
            <CardDescription>Latest transactions</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            <p className="text-sm">Alex paid $45.50 for Dinner</p>
            <p className="text-sm">You paid $22.00 for Groceries</p>
            <p className="text-sm">Jamie settled $35.75</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <section>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold">Your Groups</h2>
            <Link href="/groups/new">
              <Button className="bg-green-600 hover:bg-green-700">
                <PlusCircle className="h-4 w-4 mr-2" />
                New Group
              </Button>
            </Link>
          </div>

          <div className="space-y-4">
            <GroupCard name="Apartment" members={4} balance={125.5} isPositive={true} />
            <GroupCard name="Trip to NYC" members={6} balance={75.25} isPositive={false} />
            <GroupCard name="Dinner Club" members={5} balance={95.0} isPositive={true} />
            <GroupCard name="Office Lunch" members={8} balance={25.0} isPositive={true} />
          </div>
        </section>

        <section>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold">Recent Expenses</h2>
            <Link href="/expenses/new">
              <Button className="bg-green-600 hover:bg-green-700">
                <PlusCircle className="h-4 w-4 mr-2" />
                Add Expense
              </Button>
            </Link>
          </div>

          <div className="space-y-4">
            <ExpenseCard
              description="Dinner at Italian Restaurant"
              group="Dinner Club"
              amount={135.5}
              paidBy="Alex"
              date="Yesterday"
            />
            <ExpenseCard description="Groceries" group="Apartment" amount={87.25} paidBy="You" date="2 days ago" />
            <ExpenseCard description="Taxi rides" group="Trip to NYC" amount={45.0} paidBy="Jamie" date="May 5" />
            <ExpenseCard description="Coffee run" group="Office Lunch" amount={22.5} paidBy="Taylor" date="May 3" />
          </div>
        </section>
      </div>
    </div>
  )
}

function GroupCard({ name, members, balance, isPositive }) {
  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex justify-between items-center">
          <div>
            <h3 className="font-medium">{name}</h3>
            <p className="text-sm text-muted-foreground">{members} members</p>
          </div>
          <div className="text-right">
            <p className={`font-bold ${isPositive ? "text-green-600" : "text-red-500"}`}>
              {isPositive ? "+" : "-"}${Math.abs(balance).toFixed(2)}
            </p>
            <p className="text-xs text-muted-foreground">{isPositive ? "you are owed" : "you owe"}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function ExpenseCard({ description, group, amount, paidBy, date }) {
  const isPaidByYou = paidBy === "You"

  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex justify-between items-center">
          <div>
            <h3 className="font-medium">{description}</h3>
            <p className="text-xs text-muted-foreground">
              {group} • {date}
            </p>
          </div>
          <div className="text-right">
            <p className="font-bold">${amount.toFixed(2)}</p>
            <p className={`text-xs ${isPaidByYou ? "text-green-600" : "text-muted-foreground"}`}>Paid by {paidBy}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
