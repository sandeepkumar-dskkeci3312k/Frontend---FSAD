"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { CalendarIcon } from "lucide-react"
import { format } from "date-fns"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { cn } from "@/lib/utils"

export default function NewSettlementPage() {
  const [date, setDate] = useState(new Date())
  const [amount, setAmount] = useState("")
  const [selectedGroup, setSelectedGroup] = useState("")
  const [payer, setPayer] = useState("")
  const [recipient, setRecipient] = useState("you")

  // Mock data - in a real app, this would come from your database
  const groups = [
    { id: "apartment", name: "Apartment" },
    { id: "trip-to-nyc", name: "Trip to NYC" },
    { id: "dinner-club", name: "Dinner Club" },
    { id: "office-lunch", name: "Office Lunch" },
  ]

  const groupBalances = {
    apartment: [
      { id: "alex", name: "Alex", owes: 51.81 },
      { id: "jamie", name: "Jamie", owes: 39.81 },
      { id: "taylor", name: "Taylor", owes: 33.88 },
    ],
    "trip-to-nyc": [{ id: "you", name: "You", owes: 75.25 }],
    "dinner-club": [
      { id: "alex", name: "Alex", owes: 33.88 },
      { id: "jamie", name: "Jamie", owes: 33.87 },
      { id: "taylor", name: "Taylor", owes: 33.88 },
      { id: "morgan", name: "Morgan", owes: 33.87 },
    ],
    "office-lunch": [
      { id: "jordan", name: "Jordan", owes: 12.5 },
      { id: "casey", name: "Casey", owes: 12.5 },
    ],
  }

  const currentBalances = selectedGroup ? groupBalances[selectedGroup] : []

  const handleSubmit = (e) => {
    e.preventDefault()
    // Here you would typically save the settlement data
    console.log({
      date,
      amount: Number.parseFloat(amount),
      group: selectedGroup,
      payer,
      recipient,
    })
    // Then redirect to the group page
    if (selectedGroup) {
      window.location.href = `/groups/${selectedGroup}`
    } else {
      window.location.href = "/"
    }
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-2xl">
      <h1 className="text-3xl font-bold mb-6">Record a Payment</h1>

      <form onSubmit={handleSubmit}>
        <Card>
          <CardHeader>
            <CardTitle>Settlement Details</CardTitle>
            <CardDescription>Record a payment between group members</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="group">Group</Label>
              <Select value={selectedGroup} onValueChange={setSelectedGroup} required>
                <SelectTrigger id="group">
                  <SelectValue placeholder="Select a group" />
                </SelectTrigger>
                <SelectContent>
                  {groups.map((group) => (
                    <SelectItem key={group.id} value={group.id}>
                      {group.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {selectedGroup && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="payer">Who paid?</Label>
                  <Select value={payer} onValueChange={setPayer} required>
                    <SelectTrigger id="payer">
                      <SelectValue placeholder="Select who paid" />
                    </SelectTrigger>
                    <SelectContent>
                      {currentBalances.map((balance) => (
                        <SelectItem key={balance.id} value={balance.id}>
                          <div className="flex items-center gap-2">
                            {balance.name}
                            {balance.owes > 0 && (
                              <span className="text-xs text-muted-foreground">(owes ${balance.owes.toFixed(2)})</span>
                            )}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="recipient">Who received the payment?</Label>
                  <Select value={recipient} onValueChange={setRecipient} required>
                    <SelectTrigger id="recipient">
                      <SelectValue placeholder="Select who received payment" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="you">You</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </>
            )}

            <div className="space-y-2">
              <Label htmlFor="amount">Amount</Label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2">$</span>
                <Input
                  id="amount"
                  type="number"
                  step="0.01"
                  min="0.01"
                  className="pl-8"
                  placeholder="0.00"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="date">Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant={"outline"}
                    className={cn("w-full justify-start text-left font-normal", !date && "text-muted-foreground")}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {date ? format(date, "PPP") : <span>Pick a date</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar mode="single" selected={date} onSelect={setDate} initialFocus />
                </PopoverContent>
              </Popover>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">Notes (Optional)</Label>
              <Textarea id="notes" placeholder="Add any additional details..." />
            </div>
          </CardContent>
          <CardFooter>
            <Button type="submit" className="w-full bg-green-600 hover:bg-green-700">
              Record Payment
            </Button>
          </CardFooter>
        </Card>
      </form>
    </div>
  )
}
